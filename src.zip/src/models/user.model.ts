import mongoose from "mongoose";
import {IUser} from "../types/user.type"
import { ROLE_PERMISSIONS } from "../constants/roles.config";

const userSchema = new mongoose.Schema<IUser>(
  {
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      validate: {
        validator: (value: string) => {
          return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
        },
        message: "Invalid email format",
      },
      lowercase: true,
    },
    password: {
      type: String,
      required: function () {
        // Only require password if no social logins exist
        return this.socialLogins?.length === 0;
      },
    },
    businessName: {
      type: String,
      trim: true,
      maxlength: [100, "First name cannot exceed 50 characters"],
      required: false,
    },
    profile: {
      firstName: {
        type: String,
        trim: true,
        maxlength: [50, "First name cannot exceed 50 characters"],
      },
      lastName: {
        type: String,
        trim: true,
        maxlength: [50, "Last name cannot exceed 50 characters"],
      },
      phoneNumber: {
        type: String,
        validate: {
          validator: (value: string) => {
            // Match international-style numbers, allow spaces and dashes, but disallow dots
            const pattern = /^\+?[1-9]\d{0,3}[-\s]?\(?\d{2,4}\)?[-\s]?\d{3,4}[-\s]?\d{3,4}$/;
            return pattern.test(value);
          },
          message: "Invalid phone number format. Please use an international format like +234 801 234 5678",
        }        
      },
      avatar: {
        type: String,
        required: false,
      },
      sex: {
        type: String,
        enum: {
          values: ["Male", "Female"],
          message: "sex must be either Male or Female",
        },
      },
    },
    isEmailVerified: { type: Boolean, default: false },
    addresses: [
      {
        type: {
          type: String,
          enum: {
            values: ["billing", "shipping"],
            message: "Address type must be either billing or shipping",
          },
          required: [true, "Address type is required"],
        },
        _id: {
          type: mongoose.Schema.Types.ObjectId,
          auto: true,
        },
        street: {
          type: String,
          required: [true, "Street address is required"],
          trim: true,
          maxlength: [100, "Street address cannot exceed 100 characters"],
        },
        city: {
          type: String,
          required: [true, "City is required"],
          trim: true,
          maxlength: [50, "City name cannot exceed 50 characters"],
        },
        state: {
          type: String,
          trim: true,
          maxlength: [50, "State name cannot exceed 50 characters"],
        },
        country: {
          type: String,
          required: [true, "Country is required"],
          trim: true,
          maxlength: [50, "Country name cannot exceed 50 characters"],
        },
        postalCode: {
          type: String,
          required: [true, "Postal code is required"],
          validate: {
            validator: (value: string) => {
              // Basic international postal code validation
              return /^[A-Za-z0-9 -]{2,10}$/.test(value);
            },
            message: "Invalid postal code format",
          },
        },
        isDefault: {
          type: Boolean,
          default: false,
        },
      },
    ],
    socialLogins: [
      {
        provider: {
          type: String,
          required: [true, "Social login provider is required"],
          enum: {
            values: ["google", "facebook", "apple"],
            message: "Unsupported social login provider",
          },
        },
        providerId: {
          type: String,
          required: [true, "Social login provider ID is required"],
        },
      },
    ],
    role: {
      type: String,
      enum: {
        values: ["personal", "business", "admin"],
        message: "Invalid user role",
      },
      default: "personal",
    },
    status: {
      type: String,
      enum: {
        values: ["active", "inactive", "suspended"],
        message: "Invalid user status",
      },
      default: "active",
    },
    canMakeSales: {
      type: Boolean,
      default: false,
    },
    saleLimit: {
      type: Number,
      default: 0
    },
    salesCount: {
      type: Number,
      default: 0
    },
    preferences: {
      language: {
        type: String,
        default: "en",
      },
      currency: {
        type: String,
        default: "USD",
      },
      notifications: {
        email: {
          stockAlert: {
            type: Boolean,
            default: true,
          },
          orderStatus: {
            type: Boolean,
            default: true
          },
          pendingReviews: {
            type: Boolean,
            default: true
          },
          paymentUpdates: {
            type: Boolean,
            default: true
          },
          newsletter: {
            type: Boolean,
            default: true
          }
        },
        push: { type: Boolean, default: true },
        sms: { type: Boolean, default: false },
      },
      marketing: { type: Boolean, default: false },
    },
    paymentInformation: {
      defaultGateway: {
        type: String,
        enum: ['stripe', 'paystack', 'flutterwave'],
        default: 'stripe'
      },
      cards: [{
        gateway: {
          type: String,
          enum: ['stripe', 'paystack', 'flutterwave'],
          default: 'stripe'
        },
        last4: String,
        brand: String,
        expMonth: Number,
        expYear: Number,
        cardHolderName: String,
        country: String,
        isDefault: Boolean,
        addedAt: Date,
        metadata: {
          stripe: {
            customerId: String,
            cardId: String,
            fingerprint: String
          },
          paystack: {
            authorizationCode: String,
            bin: String,
            bank: String,
            cardType: String,
            reusable: Boolean
          },
          flutterwave: {
            token: String,
            cardType: String,
            issuingBank: String,
            bin: String
          }
        },
        billingAddressId: {
          type: mongoose.Schema.Types.ObjectId,
        }
      }]
    },
    activity: {
      lastLogin: Date,
      lastPurchase: Date,
      totalOrders: { type: Number, default: 0, min: 0 },
      totalSpent: { type: Number, default: 0, min: 0 },
    },
    // Removed cart and wishlist - using separate models + Redis
    resetPasswordToken: String,
    resetPasswordExpiresAt: Date,
    verificationToken: String,
    verificationTokenExpiresAt: Date,
    twoFactorAuth: {
      enabled: {
        type: Boolean,
        default: false
      },
      secret: {
        type: String,
        default: null
      },
      tempSecret: {
        type: String,
        default: null
      },
      backupCodes: [{
        code: String,
        used: {
          type: Boolean,
          default: false
        }
      }]
    },
    adminRole: {
      type: String,
      enum: Object.keys(ROLE_PERMISSIONS),
    },
    permissions: {
      type: [String],
      default: [], // Can override/extend base role
    },
  },
  {
    timestamps: true,
    // Enable virtuals when converting to JSON
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

const User = mongoose.model<IUser>("User", userSchema);

export default User;
